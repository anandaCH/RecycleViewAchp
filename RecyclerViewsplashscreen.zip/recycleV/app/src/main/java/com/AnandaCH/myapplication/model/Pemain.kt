package com.AnandaCH.myapplication.model

data class Pemain(
    var nama : String,
    var foto : Int,
    var posisi : String,
    var Tinggi : String,
    var tempatlahir : String,
    var tgllahir : String
)
